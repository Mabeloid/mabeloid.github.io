
for i, (error) in enumerate([
        KeyError, TypeError, ImportError, UnicodeError, ReferenceError,
        FloatingPointError
]):

    raise error("<- handled error bleh" + "h" * int(i**1.5))
    sleep(500)