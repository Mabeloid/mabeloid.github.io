from picross_board_func import displayboard


def displaytwohex(enb: bytes, jpb: bytes) -> str:
    enb = " ".join([enb.hex()[i:i+8] for i in range(0, 64, 8)]).upper()
    jpb = " ".join([jpb.hex()[i:i+8] for i in range(0, 64, 8)]).upper()
    dif = ""
    for a,b in zip(enb, jpb):
        dif += "*" if a != b else " "
    return "\n".join([enb, dif, jpb])

def displaytwoboards(enb: bytes, jpb: bytes) -> str:
    enb = displayboard(enb, False).split("\n")
    jpb = displayboard(jpb, False).split("\n")
    offset = len(enb[-1]) + 1
    outtext = []
    for enrow, jprow in zip(enb, jpb):
        outtext.append(enrow.ljust(offset) + jprow)
    return "\n".join(outtext)


with open("picross.gb", "rb") as f:
    ENROM = f.read()

with open("picross jp.gb", "rb") as f:
    JPROM = f.read()

with open("compare.txt", "w") as f:
    f.write("")

def LOG(*args, sep:str=" "):
    line = sep.join([str(a) for a in args])
    with open("compare.txt", "a") as f:
        f.write(line + "\n")

i = 0
while ENROM:
    enb = ENROM[:32]
    jpb = JPROM[:32]
    if enb != jpb:
        LOG(f"{i}\t{hex(i*32)}", displaytwohex(enb, jpb), "", sep="\n")
    ENROM = ENROM[32:]
    JPROM = JPROM[32:]
    i += 1
    #if i == 10: break
print("done!")