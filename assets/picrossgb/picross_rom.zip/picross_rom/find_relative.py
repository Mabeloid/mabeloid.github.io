with open("picross.gb", "rb") as f:
    ROM = f.read()

with open("compare.txt", "w") as f:
    f.write("")


def LOG(*args, sep: str = " "):
    line = sep.join([str(a) for a in args])
    with open("compare.txt", "a") as f:
        f.write(line + "\n")


print("about to differ the ROM")

relROM = b""
for a, b in zip(ROM, ROM[1:]):
    r = (b - a)
    if r < -128: r += 128
    elif r > 127: r -= 128
    #print(a, b, (b-a), r, sep="\t")
    relROM += r.to_bytes(signed=True)
print("differed ROM")

searchfor = "h<e<a<r<t"
charpairs = [*zip(searchfor, searchfor[1:])]

reltarget = [(ord(b) - ord(a)) for a, b in charpairs]

allfinds: list[set[int]] = []
for rel in reltarget:
    rel = (rel).to_bytes(signed=True)
    relfinds = set()
    where = 0
    while (where := relROM.find(rel, where) + 1) != 0:
        relfinds.add(where)
    allfinds.append(relfinds)

for ITER in range(5):
    for i in reversed(range(len(allfinds) - 1)):

        for candidate in frozenset(allfinds[i]):
            if not (candidate + 1 in allfinds[i + 1]):
                allfinds[i].remove(candidate)

for i, relfinds in enumerate(allfinds):
    string = f"{searchfor[i:]}".ljust(10)
    string += f"{reltarget[i:]}".ljust(20)
    l = len(relfinds)
    where = "  ".join(sorted([hex(j) for j in relfinds]))
    string += where if 0 < l < 20 else f"({l} matches)"
    print(string)
