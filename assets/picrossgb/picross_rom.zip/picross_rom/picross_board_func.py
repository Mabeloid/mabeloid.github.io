from picross_common import *


def board2str(board: bytes) -> str:
    all_rows = []
    for row in zip(board[0::2], board[1::2]):
        row_str = ""
        for byte in row:
            row_str += bin(byte)[2:].rjust(8, "0")
        all_rows.append(row_str)
    board_str = "\n".join(all_rows)
    return board_str


def board_graylastline(board_str: str):
    """Grays the last line because it encodes
    the board size and isn't actually important"""
    lines = board_str.split("\n")
    lines[-1] = f"{gray}{lines[-1]}{nocolor}"
    return "\n".join(lines)


def str2board(string: str) -> bytes:
    """Takes a string from a raw text file read()ed
    by open() and converts it to ROM bytes
    
    Cropped to the top left 15x15 if necessary"""

    rows = string.split("\n")[:16]

    height = len(rows)

    outbytes = bytes()
    width = 0
    for row in rows:
        row = row[:15 + (height == 16)]
        rowbin = ""
        hpad = 16 - len(row)
        for c in row:
            rowbin += "0" if c in ZEROS else "1"
        rowbin += "0" * hpad
        width = max(width, len(rowbin.rstrip("0")))
        rowL, rowR = int(rowbin[:8], 2), int(rowbin[8:], 2)
        rowbytes = rowL.to_bytes(length=1, byteorder="big") + rowR.to_bytes(
            length=1, byteorder="big")
        outbytes += rowbytes

    vpad = 15 - len(rows)
    for _ in range(vpad):
        outbytes += (0).to_bytes(length=1, byteorder="big") * 2

    if (width % 5): width += 5 - (width % 5)
    if (height % 5): height += 5 - (height % 5)

    if config["allowrect"] == "y":
        outbytes += width.to_bytes(length=1, byteorder="big")
        outbytes += height.to_bytes(length=1, byteorder="big")
    elif height == 20:
        #height is 16, last line is size data
        pass
    else:
        squaresize = max(width, height)
        outbytes += squaresize.to_bytes(length=1, byteorder="big") * 2

    return outbytes


def loadboard(ID: int) -> bytes:
    #if not ID in range(0, 257): rederror(IndexError, "Board ID out of valid range!")
    i = 0x92b0 + ID * 32
    return ROM[i:i + 32]


def replace_board(ROM: bytes, board: bytes, ID: int) -> bytes:
    if len(board) != 32:
        rederror(IndexError, "Board is somehow not 32 bytes long!")
    if not ID in range(0, 257):
        rederror(IndexError, "Board ID out of valid range!")

    i = 0x92b0 + ID * 32
    ROM = ROM[:i] + board + ROM[i + len(board):]
    return ROM


def debinarize_board(board_str: str) -> str:
    """Replaces 0s and 1s with more readable characters"""
    board_str = board_str.replace("0", config["displayblank"])
    board_str = board_str.replace("1", config["displayfilled"])
    return board_str


def board_is_valid(board: bytes) -> dict[str, str]:
    """Returns a dict of all rows and columns of the
    board that have more than six numbers
    
    If none do, the dict is empty"""
    errors = {}
    board_str = board2str(board)

    rows = board_str.split("\n")
    for i, row in enumerate(rows):
        bits = [x for x in row.split("0") if x]
        if len(bits) > 6: errors[f"row {i+1}"] = row

    cols = [board_str[i::17] for i in range(15)]
    for i, col in enumerate(cols):
        bits = [x for x in col.split("0") if x]
        if len(bits) > 6: errors[f"col {i+1}"] = col

    return errors


def boardsize(board_bytes: bytes) -> tuple:
    return (board_bytes[-2], board_bytes[-1])


def displayboard(board_bytes: bytes, gray: bool = True) -> str:
    """Visualizes a board, using the config's un/filled chars,
    graying the last line, and addending the encoded size"""
    board_str = debinarize_board(board2str(board_bytes))
    size = boardsize(board_bytes)
    string = f"{board_str} {size}"
    if gray: string = board_graylastline(string)
    return string


def strfromimg(inpath: str) -> str:
    """Loads an image (assumed to exist and fit within 15x15)
    and turns it into a string of 0/1, each row separated by newlines"""
    try:
        import cv2
        import numpy as np
    except ImportError:
        errortext = "Python can not load images without OpenCV2 and NumPY installed!\n"
        errortext += "To install them, open a terminal window and enter\n"
        errortext += "\tpip install opencv2\n"
        errortext += "and\n"
        errortext += "\tpip install numpy"
        rederror(ImportError, errortext)

    image: np.ndarray = cv2.imread(inpath)
    if image is None:
        raise FileNotFoundError(
            f"Image inpath {inpath} not found" +
            " (should have been caught earlier in the program)")

    if len(image.shape) == 3:
        image = np.average(image[:, :, :3], axis=2)
    image = (image > 127).astype(int)
    if config["filldark"] == "y": image = 1 - image
    board_str = "\n".join(["".join([str(c) for c in row]) for row in image])
    return board_str


def undouble(text: str) -> str:
    newtext = []
    for line in text.split("\n"):
        newtext.append(line[::2])
    newtext = "\n".join(newtext)
    return newtext


def double(text: str) -> str:
    newtext = ""
    for c in text:
        newtext += c
        if c != "\n": newtext += c
    return newtext


if False and __name__ == "__main__":
    """Visualizes entire ROM as if it were all boards"""
    with open("log.log", "w") as f:
        f.write("")
    for i in range(-1173, 500_000):
        board = loadboard(i)
        if not board: break
        j = i + 1174
        h = "0x" + hex(j * 32)[2:].upper()
        LOG(j, h, sep="\t")
        LOG(displayboard(board, gray=False))
    print("done")
