from picross_board_func import *


def tryload() -> bytes | None:
    print(f'{yellow}LOAD FROM:{nocolor}')
    FROM = take_input('Write a path to a PNG image, a text file,' +
                      ' or a number between 0 and 256 to load' +
                      ' that puzzle from the ROM\n')
    if (inpath := find_path(FROM)) is not None:
        if inpath.endswith(".png"):
            board_str = strfromimg(board_str)
        else:
            with open(inpath) as f:
                board_str = f.read().rstrip("\n")
            undoubled = undouble(board_str)
            if board_str == double(undoubled):
                if config["autoundouble"] == "y":
                    board_str = undoubled
                elif config["autoundouble"] != "n":
                    cfrm = take_input(
                        f'{yellow}Input text seems to have doubled' +
                        f' characters, undouble them? "Y":\n{nocolor}')
                    if cfrm in {'y', 'Y', '"y"', '"Y"'}:
                        board_str = undoubled

        if config["recalcboardsize"] == "y" and board_str.count("\n") == 15:
            print(f'{yellow}Input text is 16 lines tall, assuming last' +
                  f' line is size data and discarding it...{nocolor}')
            board_str = board_str[:board_str.rindex("\n")]
        return str2board(board_str)

    elif FROM.isdigit():
        return loadboard(int(FROM))
    else:
        print("Invalid input!")
    return None


def confirmload(LOADED: bytes | None) -> bytes | None:
    if LOADED is None: return None

    print(f"{yellow}Loaded board:{nocolor}")
    print(displayboard(LOADED))
    errors = board_is_valid(LOADED)

    if errors:
        faults = [
            f"{k}:".ljust(8) + debinarize_board(v) for k, v in errors.items()
        ]
        text = "This board has rows and/or columns with more"
        text += " than 6 numbers, making it unsolvable!\n"
        text += "\n".join(faults)
        rederror(IndexError, text)

    cfrm = take_input(f'{yellow}Confirm selection with "Y":\n{nocolor}')
    if cfrm in {'y', 'Y', '"y"', '"Y"'}:
        return LOADED
    return None


def trysave() -> int | None:
    print(f'{yellow}SAVE TO:{nocolor}')
    SAVETO = take_input('Write a number between 0 and 256 to overwrite\n')
    if not SAVETO.isdigit():
        print("Not a number!")
    elif not int(SAVETO) in range(0, 257):
        print("Number must be between 0 and 256 inclusive!")
    else:
        return int(SAVETO)
    return None


def confirmsave(SAVETO: int) -> bool:
    overwritten = loadboard(SAVETO)
    print("Board to be overwritten:")
    print(displayboard(overwritten))
    if SAVETO == 0:
        print(red + "Note: replacing the How To Play" +
              " puzzle causes minor graphical bugs" + nocolor)

    cfrm = take_input(f'{yellow}Confirm selection with "Y":\n{nocolor}')
    if not cfrm in {'y', 'Y', '"y"', '"Y"'}:
        return False
    return True


if __name__ == "__main__":
    LOADED = None
    while LOADED is None:
        LOADED = tryload()
        LOADED = confirmload(LOADED)

    SAVED = False
    while not SAVED:
        SAVETO = None
        while SAVETO is None:
            SAVETO = trysave()
        SAVED = confirmsave(SAVETO)

    ROM = replace_board(ROM, LOADED, int(SAVETO))
    saverom(ROM)
    print(f"{green}Successfully saved board!{nocolor}")
else:
    import sys
    sys.exit("why did you import this")
