foo: list[
    str |
    int]  #if this line causes an error, you need to update your python installation!

import os

DIR = os.path.dirname(__file__)

red = ""
green = ""
yellow = ""
gray = ""
nocolor = ""

ZEROS = {" ", ".", ",", "0"}
#PRESS_A = green + "Ⓐ" + nocolor
CTRL_CHARS = set(range(0, 0x20)).union(set(range(0x7f, 0x98)))


def rederror(e: Exception, text: str) -> None:
    raise e(red + text + nocolor)


def find_path(path: str) -> str:  #or None
    if os.path.exists(path): return path
    abs_path = f"{DIR}/{path}"
    if os.path.exists(abs_path): return abs_path
    else: return None


def take_input(prompt: str) -> str:
    output = input(prompt)
    if output.endswith('.py"'):
        import sys
        sys.exit("sys.exit() DEBUG TEXT HERE")
    return output


def LOG(*args, sep: str = " ", end: str = "\n"):
    line = sep.join([str(a) for a in args])
    with open(f"{DIR}/log.log", "a") as f:
        f.write(line + end)


def hexa(h: int, len: int = 2) -> str:
    return hex(h)[2:].upper().rjust(len, "0")

cfgpath = f"{DIR}/picross.config"
if not os.path.exists(cfgpath):
    rederror(FileNotFoundError, "Config file not found!")

config = {
    "printcolors": "n",
    "displayblank": "..",
    "displayfilled": "##",
    "filldark": "y",
    "autoundouble": "n",
    "allowrect": "n",
    "recalcboardsize": "y",
}
with open(cfgpath) as f:
    for line in f.read().split("\n"):
        if not line: continue
        if line.startswith("//"): continue
        if not ":" in line: continue
        key, *value = line.split(":")
        value = ":".join(value).lstrip(" ")
        config[key] = value

if config["printcolors"] == "y":
    red = f"\u001b[38;5;{1}m"
    green = f"\u001b[38;5;{2}m"
    yellow = f"\u001b[38;5;{3}m"
    gray = f"\u001b[38;5;{8}m"
    nocolor = "\u001b[0m"

if not "tablepath" in config:
    rederror(KeyError, '"tablepath" field missing from config file!')
tablepath = find_path(config["tablepath"])
if not tablepath:
    rederror(FileNotFoundError,
             f'Provided .tbl path "{config["tablepath"]}" not found!')

table: dict[int, str] = {}
try:
    with open(tablepath, "r", encoding="utf-8") as f:
        chars = f.read().split("\n")
except UnicodeDecodeError:
    with open(tablepath, "r") as f:
        chars = f.read().split("\n")
for char in chars:
    key, value = char.split("=")
    table[int(key, 16)] = value

rev_table = dict([(v, k) for k, v in table.items()])

if not "rompathin" in config:
    rederror(KeyError, '"rompathin" field missing from config file!')
rompathin = find_path(config["rompathin"])
if not rompathin:
    rederror(FileNotFoundError,
             f'ROM in path "{config["rompathin"]}" not found!')

if not "rompathout" in config:
    rederror(KeyError, '"rompathout" field missing from config file!')

romfolderout = os.path.dirname(config["rompathout"])
romfolderout = find_path(romfolderout)
if not romfolderout:
    rederror(
        FileNotFoundError,
        f'ROM out path "{os.path.dirname(config["rompathout"])}" not found!')
rompathout = romfolderout + "/" + os.path.basename(config["rompathout"])

with open(rompathin, "rb") as f:
    ROM = f.read()


def saverom(ROM: bytes) -> None:
    with open(rompathout, "wb") as f:
        f.write(ROM)
