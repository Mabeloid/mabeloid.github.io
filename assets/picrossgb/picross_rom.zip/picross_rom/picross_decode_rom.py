from picross_text_func import *

decode_to = f'decoded_{config["rompathin"].upper()}.txt'
decode_whole_rom(ROM, filename=decode_to)

print(f"Decoded whole rom to '{decode_to}'")
