from picross_text_func import *


def dumpalltext(ROM: bytes) -> int:
    funcs = {
        "howto": extract_hikids,
        "congratulations": extract_congrats,
        "puzzlenames": extract_names
    }

    for i, (path, extract) in enumerate(funcs.items()):
        text = extract(ROM).replace("\t", "\n")
        with open(f"{DIR}/files/{path}.txt", "w", encoding="utf-8") as f:
            f.write(text)
        preview = text.replace("\n", "   ")[:28]
        print(f"Dumped '{preview}...' to files/{path}.txt")

    return i + 1


if __name__ == "__main__":
    i = dumpalltext(ROM)
    print(f"Dumped {i} categories of text to files folder")
