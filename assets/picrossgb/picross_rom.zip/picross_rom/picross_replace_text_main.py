from picross_text_func import *


def replace_hikids(ROM: bytes, newtext: str) -> bytes:
    existing = extract_hikids(ROM)
    e_pts = getpoints(existing)
    n_pts = getpoints(newtext)
    n_pts += [(0, None)] * (len(e_pts) - len(n_pts))

    j = 0x16a30
    k = 0
    for i, ((Es, Ec), (Ns, Nc)) in enumerate(zip(e_pts, n_pts)):
        oldbytes = ROM[j:j + (Es + 1) * 2]
        N_str = newtext[k:k + Ns]
        if Ns > Es:
            warning = f"{red}Truncating line {i+1} for being too long: {nocolor}"
            warning += N_str[:Es] + gray + N_str[Es:] + nocolor
            print(warning)
        N_str = N_str.ljust(Es, " ")  #append ZWJs
        N_str = N_str[:Es] + Ec  #crop to expected size, add separator
        newbytes = encode_str(N_str)
        if len(newbytes) != len(oldbytes):
            raise IndexError("this shouldn't be possible so idk")
        ROM = ROM[:j] + newbytes + ROM[j + len(newbytes):]

        j += (Es + 1) * 2
        k += Ns + 1
    return ROM


def replace_names(ROM: bytes, newtext: str) -> bytes:
    existing = extract_names(ROM)
    e_pts = getpoints(existing)
    n_pts = getpoints(newtext)
    n_pts += [(0, None)] * (len(e_pts) - len(n_pts))

    j = 0xd930 + names_offset(ROM)
    k = 0
    for i, ((Es, Ec), (Ns, Nc)) in enumerate(zip(e_pts, n_pts)):
        start_of_new = ROM[j] == 0x00
        j += (2 + start_of_new)
        oldbytes = ROM[j:j + (Es + 1) * 2]
        if False:
            print(f"(debug) Decoded puzzle name at ROM {hex(j)}:",
                  fullydecode(decode_str(oldbytes)))
        N_str = newtext[k:k + Ns]
        if Ns > Es:
            warning = f"{red}Truncating line {i+1} for being too long: {nocolor}"
            warning += N_str[:Es] + gray + N_str[Es:] + nocolor
            print(warning)
        N_str = N_str.center(Es, " ")  #append ZWJs
        N_str = N_str[:Es] + Ec  #crop to expected size, add separator
        newbytes = encode_str(N_str)
        if len(newbytes) != len(oldbytes):
            raise IndexError("this shouldn't be possible so idk")
        ROM = ROM[:j] + newbytes + ROM[j + len(newbytes):]

        j += (Es + 1) * 2
        k += Ns + 1
    return ROM


def allkatakana(text: str) -> str:
    outtext = ""
    for c in text:
        if "\u3040" <= c < "\u30a0":
            outtext += chr(ord(c) + 0x60)
        else:
            outtext += c
    return outtext


if False:
    path = find_path("files/puzzlenames.txt")
    with open(path, "r", encoding="utf-8") as f:
        newtext = f.read()
    #newtext = allkatakana(newtext)
    ROM = replace_names(ROM, newtext)
    saverom(ROM)

texts = {
    "How To": replace_hikids,
    #"congratulations": replace_congrats,
    "Puzzle Names": replace_names
}

options_str = "\n".join([f"{i}\t{name}" for i, name in enumerate(texts)])

if __name__ == "__main__":
    sel_i = None
    while sel_i is None:
        prompt = "Enter the corresponding number to replace one of the following texts:"
        sel_i = take_input(f"{yellow}{prompt}\n{options_str}\n{nocolor}")
        if not sel_i.isdigit():
            print("Invalid input!")
            sel_i = None
        elif int(sel_i) not in range(len(texts)):
            print("Invalid input!")
            sel_i = None
        else:
            sel_i = int(sel_i)

    (name, replace) = list(texts.items())[sel_i]

    path = None
    while path is None:
        path = take_input(f"{yellow}Enter path to text file to " +
                          f"replace the {name} text with:\n{nocolor}")
        path = find_path(path)
        if path is None: print("Path not found!")

    with open(path, "r", encoding="utf-8") as f:
        newtext = f.read()
    #newtext = allkatakana(newtext)
    ROM = replace(ROM, newtext)
    saverom(ROM)
    print(green + f"Replaced the {name} text successfully!" + nocolor)
