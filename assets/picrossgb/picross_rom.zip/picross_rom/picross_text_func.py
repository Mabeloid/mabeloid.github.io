from picross_common import *

HI_KIDS = 0x16a30
CONGRAT = 0x3fc0
PUZZLENAMES = 0xd930


def rompart2str(ROMPART: bytes, doprint: bool = False) -> str:
    text = ""
    for char in ROMPART:
        if char in table:
            text += table[char]
        else:
            if char == 0: unknownchar = "█"
            elif char in CTRL_CHARS:
                unknownchar = "\ufffd"
                #else: unknownchar = "\ufffd"
            else:
                unknownchar = chr(char)
            #unknownchar = red + unknownchar + nocolor
            if doprint:
                print(f"Unknown char: {char} / " +
                      f"{hexa(char)} ({unknownchar})")
            text += unknownchar
    #text += nocolor
    return text


def decode_whole_rom(ROM: bytes,
                     linesize: int = 0x50,
                     filename: str = "decoded_rom.txt",
                     printlines: bool = False) -> None:
    """Decodes entire ROM to text, formats it nicely, and saves it"""
    fulltext = []
    for i in range(len(ROM) // linesize):
        PART = ROM[linesize * i:linesize * (i + 1)]
        line = rompart2str(PART)
        line = "\t".join([hex(i * linesize), line])
        if printlines: print(line)
        fulltext.append(line)
    text = "\n".join(fulltext)

    with open(filename, "w", encoding="utf-8") as f:
        f.write(text)


def decode_str(b_str: bytes) -> str:
    text = ""
    for char in b_str:
        if char in table:
            text += table[char]
        else:
            if char == 0: unknownchar = "█"
            elif char in CTRL_CHARS:
                unknownchar = "\ufffd"
            else:
                unknownchar = chr(char)
            text += unknownchar
    return text


def fullydecode(text: str) -> str:
    """Unseparates NULL characters, represents new
    textbox as newline and A button promt as tabulator"""
    newtext = ""
    for a, b in zip(text[0::2], text[1::2]):
        if a + b == "þÿ": newtext += "\n"
        elif a + b == "ÿÿ": newtext += "\t"
        else: newtext += a
    newtext = newtext.lstrip(table[0]).rstrip(table[0])
    return newtext


def encode_str(string: str) -> bytes:
    out_b = b""
    for c in string:
        if c in rev_table:
            new_c = rev_table[c].to_bytes() + b"\0"
        elif c == "\n":
            new_c = bytes("þÿ", encoding="ANSI")
        elif c == "\t":
            new_c = bytes("ÿÿ", encoding="ANSI")
        else:
            new_c = ord(c).to_bytes() + b"\0"
        out_b += new_c
    return out_b


def getpoints(fully_decoded: str) -> list[tuple[int, str]]:
    points = []
    streak = 0
    for c in fully_decoded:
        if c in ("\t", "\n"):
            points.append((streak, c))
            streak = 0
        else:
            streak += 1
    return points


def extract_hikids(ROM: bytes) -> str:
    b_str = ROM[0x16a30:0x17f70]
    text = decode_str(b_str)
    text = fullydecode(text)
    return text


def extract_congrats(ROM: bytes) -> str:
    b_str = ROM[0x4000:0x43d0]
    text = decode_str(b_str)
    text = fullydecode(text)
    l = 0
    for _ in range(7):
        l = text.find("\t", l) + 1
    text = text[:l]
    return text


def names_offset(ROM: bytes) -> int:
    b_str = ROM[0xd930:0xec90]
    if b_str.startswith(bytes.fromhex("4f6c")): return 2  #en
    if b_str.startswith(bytes.fromhex("9465")): return 8  #jp
    return 0


def extract_names(ROM: bytes) -> str:
    b_str = ROM[0xd930:0xec90]
    text = decode_str(b_str)

    #datacol:dict[int,dict[int,int]] = {}

    i, j = 0, 0
    names = []
    while (j := text.find("ÿÿ", j) + 2) != 1:
        name = text[i:j]
        start_of_new = name[0] == table[0]
        if start_of_new: name = name[1:]

        split = 2
        if i == 0: split += names_offset(ROM)

        sizedata, name = name[:split], name[split:-2]
        name = fullydecode(name)

        if False:
            #b = rev_table[sizedata[-2]]
            #if not b in datacol: datacol[b] = {}
            #datacol[b][len(name)] = datacol[b].get(len(name), 0) + 1
            if start_of_new: sizedata = table[0] + sizedata
            show_size = encode_str(sizedata)[::2]
            show_size = [hexa(h) for h in show_size]
            show_size = ", ".join(show_size).rjust(10)
            show_size = f'[{show_size}]'
            print(f"{i}:{j}".center(9), sizedata, show_size, name, sep="\t")

        names.append(name)
        i = j

    #for k,v in sorted(datacol.items()): print(f"{k} ({table[k]}): {v}")
    return "\t".join(names + [""])


if __name__ == "__main__":
    print(extract_names(ROM))
